/* TwinVM Stage 0 — Android JNI 桥
 * stage0(): 完整跑一遍"用户态虚拟机"（fork 槽位 → seccomp 拦截 → ROM 装载 guest → 原生执行）
 * probe(): 探测本机 seccomp 拦截可用性（fork 子进程试装，不污染主进程） */
#include <jni.h>
#include "vm_core.h"

#include <android/log.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include "bpf_gen.h"   /* v0.7.51: 全量放行清单（策略审计用） */
#include <sys/prctl.h>
#include <sys/ucontext.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "TwinVM", __VA_ARGS__)

/* ── v0.7.40：卡死可见化 ──────────────────────────────────────────────
 * 真机教训：ART 越走越深之后，某一步会**卡住**（不是崩），而日志是 native 返回后
 * 才落盘的 → 卡死时既没有日志、UI 又永远停在"运行中"，没法定位。
 * 现在：① 控制台每读到一段就**立刻追加**写进 twinvm-live.log（卡死也留现场）；
 *       ② poll + 看门狗：连续 VM_HANG_SILENCE_S 秒没有任何输出（或总时长超 VM_HANG_TOTAL_S）
 *          就判定卡死、SIGKILL 槽位、把"最后现场"交回 UI。 */
#ifndef VM_HANG_SILENCE_S
#define VM_HANG_SILENCE_S 30
#endif
#ifndef VM_HANG_TOTAL_S
#define VM_HANG_TOTAL_S  120
#endif
#define VM_LIVE_MAX      (4u << 20)
/* v0.7.41：日志暴走（= syscall 死循环）判定。正常一整轮自检的控制台输出约 0.5MB；
 * 8.7M 次 ENOSYS 那种暴走会瞬间冲到几 MB。到 VM_CONSOLE_MAX 就判"暴走"、强杀槽位、
 * 立刻把现场交回 UI —— 不用等看门狗的超时。 */
#define VM_CONSOLE_MAX   (6u << 20)

static int g_live_fd = -1;
static void live_write(const char* p, size_t n) {
    if (g_live_fd >= 0 && n) { ssize_t w = write(g_live_fd, p, n); (void)w; }
}

static void jni_fault_diag(int sig, siginfo_t* si, void* vuc) {
    ucontext_t* uc = (ucontext_t*)vuc;
    /* 注意：regs[] 只有 x0..x30（31 项），sp/pc/pstate 是 struct sigcontext 的独立字段，
     * v0.2.7 用 r[31]/r[32] 顶 sp/pc 属于越界读（读到 __reserved），v0.2.8 改正。 */
    uint64_t* r = uc->uc_mcontext.regs;
    char b[1024];
    int k = snprintf(b, sizeof(b),
        "[TwinVM] GUEST FAULT: sig=%d addr=%p pc=0x%lx\n"
        "  x0=0x%llx x1=0x%llx x2=0x%llx x3=0x%llx\n"
        "  x4=0x%llx x5=0x%llx sp=0x%lx fp(x29)=0x%llx lr=0x%llx\n",
        sig, si->si_addr, (unsigned long)uc->uc_mcontext.pc,
        (unsigned long long)r[0], (unsigned long long)r[1],
        (unsigned long long)r[2], (unsigned long long)r[3],
        (unsigned long long)r[4], (unsigned long long)r[5],
        (unsigned long)uc->uc_mcontext.sp, (unsigned long long)r[29],
        (unsigned long long)r[30]);
    vm_console_write(b, (size_t)k);
    /* FP 回溯（arm64 帧指针链：[fp]=caller fp, [fp+8]=ret addr） */
    uint64_t fp = r[29];
    k = snprintf(b, sizeof(b), "  backtrace:");
    for (int i = 0; i < 8 && fp > 0x1000; i++) {
        uint64_t fpv[2];
        if (vm_mem_read(&vm_machine_current()->mem, fpv, fp, 16) != 0) break;
        k += snprintf(b + k, sizeof(b) - (size_t)k, " 0x%llx", (unsigned long long)fpv[1]);
        fp = fpv[0];
        if (k > 900) break;
    }
    snprintf(b + k, sizeof(b) - (size_t)k, "\n");
    vm_console_write(b, strlen(b));
    /* 最近 TRAP 的 syscall 序列 */
    VmCpu* c = vm_machine_current();
    k = snprintf(b, sizeof(b), "  recent syscalls:");
    int n = c ? c->nr_hist_n : 0;
    for (int i = n < 12 ? 0 : n - 12; i < n; i++)
        k += snprintf(b + k, sizeof(b) - (size_t)k, " %ld", c->nr_hist[i]);
    snprintf(b + k, sizeof(b) - (size_t)k, "\n");
    vm_console_write(b, strlen(b));
    _exit(89);
}

/* 4.2.1：把捕获的控制台字节流变成 Java 字符串。
 * 关键坑（2026-10-13 16:25 日志实锤）：NewStringUTF 收的是 C 字符串，**遇到第一个
 * 0x00 就结束**。guest 往 logd socket 的 writev 负载（struct log_msg，4KB 里大片是 0）
 * 被引擎 tee 到控制台后，整个日志就在那一刻被截断——连本函数追加的
 * "guest 槽位退出: code=…（死于信号 …）" 尾巴都被吞掉，现场看起来像"进程死在
 * writev 返回后、无下文"。
 * 这里做双保险：引擎侧已在 vm_console_write() 丢弃 NUL；本函数再逐字节扫一遍，
 * NUL/其余 C0 控制字符折成 '.'，并给总长设上限（防止 ART 引导期日志无限增长把
 * Java 字符串撑爆）。 */
static jstring console_to_jstring(JNIEnv* env, const char* buf, size_t len) {
    size_t cap = len;
    const size_t LIMIT = (size_t)3 << 20;        /* 3MB 上限 */
    int truncated = 0;
    if (cap > LIMIT) { cap = LIMIT; truncated = 1; }
    char* s = (char*)malloc(cap + 64);
    if (!s) return (*env)->NewStringUTF(env, "[TwinVM] 日志缓冲区分配失败");
    size_t k = 0;
    for (size_t i = 0; i < cap; i++) {
        unsigned char c = (unsigned char)buf[i];
        if (c == 0) continue;                    /* NUL：绝不能让 C 字符串提前结束 */
        if ((c < 0x20 && c != '\n' && c != '\r' && c != '\t') || c == 0x7F) c = '.';
        s[k++] = (char)c;
    }
    if (truncated) {
        const char* note = "\n[TwinVM] （日志超 3MB 已截断）\n";
        memcpy(s + k, note, strlen(note));
        k += strlen(note);
    }
    s[k] = 0;
    jstring r = (*env)->NewStringUTF(env, s);
    free(s);
    return r;
}

/* bionic 的 strsignal 不认识 SIGSYS(31)（会打 "Unknown signal 31"），
 * 而它恰好是这套引擎最要紧的信号 —— 自己查表，别让日志含糊。 */
static const char* jni_signal_name(int sig) {
    switch (sig) {
        case 4:  return "SIGILL";
        case 5:  return "SIGTRAP";
        case 6:  return "SIGABRT";
        case 7:  return "SIGBUS";
        case 8:  return "SIGFPE";
        case 9:  return "SIGKILL";
        case 11: return "SIGSEGV";
        case 31: return "SIGSYS（系统调用被过滤器/策略拒绝）";
        default: { const char* n = strsignal(sig); return n ? n : "unknown"; }
    }
}

static void jni_install_fatal_diag(void) {
    /* 关键：不覆盖 SIGSYS（那是引擎的系统调用入口）。其余致命信号都装上诊断，
     * 这样任何"无下文"死亡都会在控制台留下 pc/寄存器/回溯 + 最近 TRAP 序列。 */
    static const int sigs[] = { SIGSEGV, SIGBUS, SIGILL, SIGABRT, SIGFPE, SIGTRAP };
    struct sigaction d;
    memset(&d, 0, sizeof(d));
    d.sa_sigaction = jni_fault_diag;
    d.sa_flags = SA_SIGINFO;
    for (size_t i = 0; i < sizeof(sigs) / sizeof(sigs[0]); i++)
        sigaction(sigs[i], &d, NULL);
}

/* 子进程 = guest 槽位（VMOS :vmsXX 的 Stage0 版） */

/* v0.7.48 —— App 策略 KILL 名单探针。
 * 真机实锤（v0.7.47）：槽位死于 SIGSYS(-31)，但**所有 TRAP 日志里都没有它**，
 * 且 blackbox 显示死亡时 SIGSYS 还处于“被屏蔽”状态 —— 只有内核直接杀
 * （SECCOMP_RET_KILL_PROCESS）才会这样绕过 handler 与屏蔽位。
 * 本函数在 App 进程里逐个 fork 子进程去调用可疑 syscall：被信号杀掉的就是
 * App 策略 KILL 名单里的（参数随意，seccomp 在参数校验之前就判）。只杀子进程。 */
struct VmPolicyProbe { const char* name; long nr; };
/* v0.7.51 —— 全量放行清单审计。
 * v0.7.50 的教训：共享黑匣子里**没有**那次致命 syscall，说明它被我们的 BPF 放行了
 * （放行 = 原生执行 = 不经过引擎 = 黑匣子看不到），随后被 App 策略
 * SECCOMP_RET_KILL_PROCESS 直接杀（无 handler、无 TRAP 行、code=-31）。
 * 所以必须把**放行清单里每一条**都拿去做一次"会不会被 App 策略杀"的实测。 */
static const struct VmPolicyProbe kAllowAudit[] = VM_BPF_ALLOW_NRS;
/* 之前已实测出 KILL 的（v0.7.48，保留做回归对照） */
/* v0.7.53：**参数化放行**的那些（不在 VM_BPF_ALLOW_NRS 里，但 BPF 会按参数放行）——
 * 全量清单审计覆盖不到它们，所以单独测。 */
static const struct VmPolicyProbe kParamAllowed[] = {
    { "write", 64 }, { "writev", 66 }, { "read", 63 }, { "close", 57 }, { "ioctl", 29 },
    { "socket", 198 }, { "connect", 203 }, { "pread64", 67 }, { "mmap", 222 },
    { "rt_sigaction", 134 }, { "fstat", 80 }, { "openat", 56 }, { NULL, 0 }
};
static const struct VmPolicyProbe kKnownKilled[] = {
    { "rseq", 293 }, { "mbind", 235 }, { "get_mempolicy", 236 }, { "set_mempolicy", 237 },
    { "migrate_pages", 238 }, { "move_pages", 239 }, { "keyctl", 250 }, { "add_key", 248 },
    { "request_key", 249 }, { "openat2", 437 }, { "faccessat2", 439 }, { NULL, 0 }
};
static int vm_try_syscall(long nr) {
    pid_t p = fork();
    if (p == 0) {
        register long x8 __asm__("x8") = nr;
        register long x0 __asm__("x0") = 0, x1 __asm__("x1") = 0, x2 __asm__("x2") = 0;
        __asm__ volatile("svc #0" : "+r"(x0) : "r"(x8), "r"(x1), "r"(x2) : "memory");
        _exit(0);
    }
    if (p < 0) return -1;
    int st = 0;
    waitpid(p, &st, 0);
    if (WIFSIGNALED(st)) return WTERMSIG(st);
    return 0;
}
static void vm_policy_probe(void) {
    char msg[320];
    int n = snprintf(msg, sizeof(msg),
        "[TwinVM] [policy] \u5ba1\u8ba1\u653e\u884c\u6e05\u5355\uff08%d \u6761\uff09\uff1a\u9010\u6761 fork \u5b50\u8fdb\u7a0b\u5b9e\u6d4b\n",
        VM_BPF_ALLOW_NRS_COUNT);
    LOGI("%s", msg); live_write(msg, (size_t)n);
    int killed = 0;
    for (int i = 0; i < VM_BPF_ALLOW_NRS_COUNT; i++) {
        int sig = vm_try_syscall(kAllowAudit[i].nr);
        if (sig == 31) {
            killed++;
            n = snprintf(msg, sizeof(msg),
                "[TwinVM] [policy] !! %s(%ld) -> SIGSYS \u2014 App \u7b56\u7565 KILL\uff01"
                "\u5fc5\u987b\u4ece\u653e\u884c\u6e05\u5355\u6458\u6389\n",
                kAllowAudit[i].name, kAllowAudit[i].nr);
        } else if (sig > 0) {
            n = snprintf(msg, sizeof(msg),
                "[TwinVM] [policy]    %s(%ld) -> \u672c\u8eab\u62a5\u4fe1\u53f7 %d\uff08\u975e KILL\uff09\n",
                kAllowAudit[i].name, kAllowAudit[i].nr, sig);
        } else {
            n = snprintf(msg, sizeof(msg),
                "[TwinVM] [policy]    %s(%ld) -> \u5b89\u5168\n", kAllowAudit[i].name, kAllowAudit[i].nr);
        }
        LOGI("%s", msg); live_write(msg, (size_t)n);
    }
    for (int i = 0; kParamAllowed[i].name; i++) {
        int sig = vm_try_syscall(kParamAllowed[i].nr);
        n = snprintf(msg, sizeof(msg),
            "[TwinVM] [policy] (\u53c2\u6570\u5316) %s(%ld) -> \u4fe1\u53f7 %d%s\n",
            kParamAllowed[i].name, kParamAllowed[i].nr, sig,
            sig == 31 ? " \u2190 App \u7b56\u7565 KILL\uff01" : "");
        LOGI("%s", msg); live_write(msg, (size_t)n);
    }
    for (int i = 0; kKnownKilled[i].name; i++) {
        int sig = vm_try_syscall(kKnownKilled[i].nr);
        n = snprintf(msg, sizeof(msg), "[TwinVM] [policy] (\u5df2\u77e5) %s(%ld) -> \u4fe1\u53f7 %d\n",
                     kKnownKilled[i].name, kKnownKilled[i].nr, sig);
        LOGI("%s", msg); live_write(msg, (size_t)n);
    }
    n = snprintf(msg, sizeof(msg),
        "[TwinVM] [policy] \u653e\u884c\u6e05\u5355\u91cc\u6709 %d \u6761\u4f1a\u88ab App \u7b56\u7565 KILL\n", killed);
    LOGI("%s", msg); live_write(msg, (size_t)n);
}
static void jni_guest_main(const VmRom* rom, int console_fd) {
    vm_console_fd = console_fd;
    vm_machine_setup(rom, (int)getpid(), 1);

    jni_install_fatal_diag();

    vm_log("guest 槽位启动 pid=%d：ROM %u inodes 就绪", (int)getpid(), rom->inode_count);

    const VmRomInode* g = vm_rom_find(rom, "/bin/guest");
    if (!g) { vm_log("ROM 缺 /bin/guest"); _exit(98); }

    VmLaunch launch;
    int r = vm_loader_prepare(g->map, g->size, &launch);
    if (r != 0) { vm_log("装载器失败: %d", r); _exit(98); }

    int sr = vm_sigsys_install(console_fd);
    if (sr != 0) { vm_log("seccomp 拦截安装失败: %d", -sr); _exit(97); }

    vm_log("拦截就绪，装载 guest entry=%p（原生 aarch64 代码，免 root）",
           (void*)launch.entry);
    vm_loader_jump(&launch);   /* guest 的 exit_group 结束本进程 */
    _exit(99);
}

JNIEXPORT jstring JNICALL
Java_dev_twinbox_vm_Native_stage0(JNIEnv* env, jclass cls, jstring romPath, jstring liveLog) {
    const char* path = (*env)->GetStringUTFChars(env, romPath, NULL);
    VmRom rom;
    int rc = vm_rom_load(&rom, path);
    (*env)->ReleaseStringUTFChars(env, romPath, path);
    if (rc != 0) {
        char b[160];
        snprintf(b, sizeof(b), "[TwinVM] ROM 装载失败: %d（assets 损坏？）", rc);
        return (*env)->NewStringUTF(env, b);
    }

    /* v0.7.48：live 日志提前打开（策略探针与后续控制台都往里写） */
    g_live_fd = -1;
    if (liveLog) {
        const char* lp = (*env)->GetStringUTFChars(env, liveLog, NULL);
        if (lp) {
            g_live_fd = open(lp, O_WRONLY | O_CREAT | O_TRUNC, 0644);
            (*env)->ReleaseStringUTFChars(env, liveLog, lp);
        }
    }
    vm_policy_probe();   /* v0.7.48：先量一下 App 策略 KILL 名单 */
    int pfd[2];
    if (pipe(pfd) != 0) return (*env)->NewStringUTF(env, "[TwinVM] pipe 失败");
    /* v0.7.50：共享黑匣子页（内核 KILL 也带得走子进程最后的 syscall） */
    VmBlackBox* bb = (VmBlackBox*)mmap(NULL, 4096, PROT_READ | PROT_WRITE,
                                       MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (bb == MAP_FAILED) bb = NULL;
    pid_t pid = fork();
    if (pid == 0) {
        close(pfd[0]);
        vm_bb_attach(bb);
        jni_guest_main(&rom, pfd[1]);
        _exit(99);
    }
    close(pfd[1]);

    size_t cap = 8192, len = 0, live_total = 0;
    char* buf = (char*)malloc(cap);
    if (!buf) { close(pfd[0]); waitpid(pid, NULL, 0); if (g_live_fd >= 0) close(g_live_fd); return (*env)->NewStringUTF(env, "[TwinVM] 内存不足"); }
    ssize_t n;
    int hang = 0;
    time_t t0 = time(NULL), last_out = t0;
    for (;;) {
        struct pollfd pf;
        pf.fd = pfd[0]; pf.events = POLLIN; pf.revents = 0;
        int pr = poll(&pf, 1, 1000);
        if (pr > 0 && (pf.revents & POLLIN)) {
            n = read(pfd[0], buf + len, cap - len);
            if (n > 0) {
                len += (size_t)n;
                last_out = time(NULL);
                if (live_total < VM_LIVE_MAX) {
                    size_t w = (size_t)n;
                    if (live_total + w > VM_LIVE_MAX) w = VM_LIVE_MAX - live_total;
                    live_write(buf + len - (size_t)n, w);
                    live_total += w;
                }
                if (len >= VM_CONSOLE_MAX) {    /* 日志暴走 → 判定死循环，停 */
                    const char* note =
                        "\n[TwinVM] !! 控制台输出超过 6MB —— 判定为日志暴走（极可能是某个 syscall\n"
                        "[TwinVM]    拿到错误后无限重试）。已强杀槽位；上面最后几行就是那个 syscall。\n";
                    size_t nl = strlen(note);
                    live_write(note, nl);
                    if (len + nl < cap) { memcpy(buf + len, note, nl); len += nl; }
                    kill(pid, SIGKILL);
                    hang = 1;
                    break;
                }
                if (len == cap) {
                    size_t ncap = cap * 2;
                    char* nb = (char*)realloc(buf, ncap);
                    if (!nb) break;             /* 内存紧张：停止收集（下方仍会给出退出码） */
                    buf = nb; cap = ncap;
                }
                continue;
            }
            if (n == 0) break;                  /* EOF：槽位退出 */
            if (errno == EINTR) continue;
            break;
        }
        /* v0.7.48：管道挂断 = 槽位已死（SIGSYS 若被内核直接杀，连 handler 都不会跑，
         * 控制台不会有任何收尾输出）。以前不处理这里，于是白等 30 秒看门狗。 */
        if (pr > 0 && (pf.revents & (POLLHUP | POLLERR | POLLNVAL))) break;
        if (pr < 0 && errno != EINTR) break;
        time_t now = time(NULL);
        /* v0.7.46 黑匣子：卡死期间每 2 秒抄子进程的 /proc/<pid>/syscall、wchan、status（SigPnd/SigBlk）。
         * SIGSYS 死亡发生在 512 条 TRAP 之后时，日志里什么都看不到，就靠它破。 */
        {
            static time_t last_probe = 0;
            if (now - last_probe >= 2) {
                last_probe = now;
                char pp[64], pbuf[512];
                snprintf(pp, sizeof(pp), "/proc/%d/syscall", (int)pid);
                int fd = open(pp, O_RDONLY);
                if (fd >= 0) {
                    ssize_t k = read(fd, pbuf, sizeof(pbuf) - 1);
                    close(fd);
                    if (k > 0) {
                        pbuf[k] = 0;
                        for (int q = 0; q < k; q++) if (pbuf[q] == '\n') pbuf[q] = ' ';
                        char out[640];
                        int n2 = snprintf(out, sizeof(out),
                            "[TwinVM] [blackbox] silent %ds; child syscall: %s\n",
                            (int)(now - last_out), pbuf);
                        live_write(out, (size_t)n2);
                        if (len + (size_t)n2 < cap) { memcpy(buf + len, out, (size_t)n2); len += (size_t)n2; }
                    }
                }
                snprintf(pp, sizeof(pp), "/proc/%d/wchan", (int)pid);
                fd = open(pp, O_RDONLY);
                if (fd >= 0) {
                    ssize_t k = read(fd, pbuf, sizeof(pbuf) - 1);
                    close(fd);
                    if (k > 0) {
                        pbuf[k] = 0;
                        char out[640];
                        int n2 = snprintf(out, sizeof(out),
                            "[TwinVM] [blackbox] child wchan: %s\n", pbuf);
                        live_write(out, (size_t)n2);
                        if (len + (size_t)n2 < cap) { memcpy(buf + len, out, (size_t)n2); len += (size_t)n2; }
                    }
                }
                snprintf(pp, sizeof(pp), "/proc/%d/status", (int)pid);
                fd = open(pp, O_RDONLY);
                if (fd >= 0) {
                    ssize_t k = read(fd, pbuf, sizeof(pbuf) - 1);
                    close(fd);
                    if (k > 0) {
                        pbuf[k] = 0;
                        const char* keep[4] = { "State:", "SigPnd:", "SigBlk:", "SigCgt:" };
                        for (int q = 0; q < 4; q++) {
                            char* hit = strstr(pbuf, keep[q]);
                            if (!hit) continue;
                            char* e = strchr(hit, '\n');
                            char tmp[160];
                            size_t tl = e ? (size_t)(e - hit) : strlen(hit);
                            if (tl > sizeof(tmp) - 1) tl = sizeof(tmp) - 1;
                            memcpy(tmp, hit, tl); tmp[tl] = 0;
                            char out[320];
                            int n2 = snprintf(out, sizeof(out), "[TwinVM] [blackbox] child %s\n", tmp);
                            live_write(out, (size_t)n2);
                            if (len + (size_t)n2 < cap) { memcpy(buf + len, out, (size_t)n2); len += (size_t)n2; }
                        }
                    }
                }
            }
        }
        if (now - last_out >= VM_HANG_SILENCE_S || now - t0 >= VM_HANG_TOTAL_S) {
            char hb[320];
            int hk = snprintf(hb, sizeof(hb),
                "\n[TwinVM] !! 看门狗：%ld 秒无任何控制台输出（累计 %ld 秒）——判定卡死，已强杀槽位。\n"
                "[TwinVM]    上面最后几行就是卡死现场（引擎的 TRAP/openat 行会指到具体位置）。\n",
                (long)(now - last_out), (long)(now - t0));
            live_write(hb, (size_t)hk);
            if (len + (size_t)hk < cap) { memcpy(buf + len, hb, (size_t)hk); len += (size_t)hk; }
            kill(pid, SIGKILL);
            hang = 1;
            break;
        }
    }
    close(pfd[0]);
    if (g_live_fd >= 0) { close(g_live_fd); g_live_fd = -1; }

    int st = 0;
    waitpid(pid, &st, 0);
    int sig = WIFSIGNALED(st) ? WTERMSIG(st) : 0;
    int code = WIFEXITED(st) ? WEXITSTATUS(st) : -sig;
    LOGI("stage0 guest slot exit=%d (signal=%d) hang=%d", code, sig, hang);

    /* v0.7.50：把共享黑匣子里的最后 32 次 syscall 倒出来（这是 KILL 也抹不掉的现场） */
    if (bb) {
        char bbl[2048];
        int off = snprintf(bbl, sizeof(bbl),
            "\n[TwinVM] [bb] \u5b50\u8fdb\u7a0b\u6700\u540e\u7684 syscall\uff08seq=%lu\uff0c\u6700\u65b0\u5728\u540e\uff09:\n", bb->seq);
        int cnt = (int)(bb->seq < 32 ? bb->seq : 32);
        int start = (bb->idx - cnt + 32) & 31;
        for (int i = 0; i < cnt && off < (int)sizeof(bbl) - 64; i++) {
            int k = (start + i) & 31;
            off += snprintf(bbl + off, sizeof(bbl) - (size_t)off,
                            "[TwinVM] [bb]   nr=%-4ld a0=0x%-12lx pc=0x%lx\n",
                            bb->nr[k], bb->a0[k], bb->pc[k]);
        }
        live_write(bbl, (size_t)off);
        if (len + (size_t)off < cap) { memcpy(buf + len, bbl, (size_t)off); len += (size_t)off; }
        munmap(bb, 4096);
    }

    char tail[512];
    if (hang)
        snprintf(tail, sizeof(tail),
                 "\n[TwinVM] guest 槽位退出: code=%d（被看门狗强杀 = 卡死，不是崩溃）\n"
                 "[TwinVM] 完整实时日志也已写盘（twinvm-live.log），上面最后几行即现场。\n", code);
    else if (sig)
        snprintf(tail, sizeof(tail),
                 "\n[TwinVM] guest 槽位退出: code=%d（死于信号 %d = %s）\n"
                 "[TwinVM] 提示: SIGSYS(31) = 系统调用被过滤器/策略拒绝（判决表/放行清单）；"
                 "SIGSEGV(11)/SIGILL(4) = 上面应有 GUEST FAULT 现场\n",
                 code, sig, jni_signal_name(sig));
    else
        snprintf(tail, sizeof(tail),
                 "\n[TwinVM] guest 槽位退出: code=%d %s\n",
                 code, code == 0 ? "（正常关机）" : "（异常）");

    char* full = (char*)malloc(len + strlen(tail) + 1);
    if (!full) { free(buf); return (*env)->NewStringUTF(env, "[TwinVM] 内存不足"); }
    memcpy(full, buf, len);
    memcpy(full + len, tail, strlen(tail) + 1);
    free(buf);
    jstring result = console_to_jstring(env, full, len + strlen(tail));   /* NUL 安全转换 */
    free(full);
    return result;
}

JNIEXPORT jstring JNICALL
Java_dev_twinbox_vm_Native_probe(JNIEnv* env, jclass cls) {
    pid_t pid = fork();
    if (pid == 0) {
        /* 无害过滤器：全部 ALLOW——只测"能不能装" */
        struct sock_filter f[] = {
            BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
        };
        struct sock_fprog prog = { 1, f };
        if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0) _exit(97);
        if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &prog) != 0) _exit(96);
        _exit(0);
    }
    int st = 0;
    waitpid(pid, &st, 0);
    int ok = WIFEXITED(st) && WEXITSTATUS(st) == 0;

    char b[512];
    snprintf(b, sizeof(b),
             "[TwinVM] TwinVM 引擎能力探测\n"
             "  架构            : %s\n"
             "  seccomp 用户态拦截 : %s\n"
             "  进程内 ELF 装载器  : 内置（绕 W^X exec 禁令）\n"
             "  ROM 虚拟文件系统   : 内置（inode 表 + crc32）\n"
             "  内核模式        : 用户态（免 root，同 VMOS 路线）\n"
             "  多 guest 槽位     : Stage 1（fork 槽位池）\n",
             vm_arch_name(),
             ok ? "可用（核心前提成立）" : "不可用（内核限制？）");
    return (*env)->NewStringUTF(env, b);
}
