package dev.twinbox.vm;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * TwinVM Stage 1 —— 用户态虚拟机自检台。
 * 纯平台 widget（零依赖，宽视口触屏友好：竖排大按钮 + 等宽输出）。
 */
public class MainActivity extends Activity implements View.OnClickListener {

    private TextView mOut;
    private Handler mUi = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 72, 48, 48);
        root.setBackgroundColor(0xFF101418);

        TextView title = new TextView(this);
        title.setText("TwinVM · 用户态虚拟机 Stage 2");
        title.setTextColor(0xFFE8EAED);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Stage 4.2：真 linker 接管——linker64 拉起 dalvikvm（ART 引导第一跳）");
        sub.setTextColor(0xFF9AA0A6);
        sub.setTextSize(13);
        sub.setPadding(0, 12, 0, 24);
        root.addView(sub);

        Button run = makeButton("运行 Stage 4.2 自检（dalvikvm 引导）");
        run.setTag("run");
        root.addView(run);

        Button probe = makeButton("引擎能力探测");
        probe.setTag("probe");
        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 16;
        root.addView(probe, lp);

        mOut = new TextView(this);
        mOut.setTypeface(Typeface.MONOSPACE);
        mOut.setTextSize(12);
        mOut.setTextColor(0xFF7EE1B4);
        mOut.setPadding(8, 24, 8, 8);
        mOut.setText("就绪。点「运行 Stage 1 自检」：\n"
                + "从 ROM 装载 guest 二进制到本进程 fork 出的槽位，\n"
                + "在其自己的用户态内核下原生执行（同 VMOS 免 root 机制）。");

        ScrollView sc = new ScrollView(this);
        sc.addView(mOut);
        root.addView(sc, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(15);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(this);
        return b;
    }

    @Override
    public void onClick(final View v) {
        final boolean isRun = "run".equals(v.getTag());
        mOut.setText("…运行中（guest 在独立槽位进程执行）");
        new Thread(new Runnable() {
            @Override
            public void run() {
                String result;
                try {
                    /* v0.7.40：把 live 日志路径也交给 native —— 卡死时也能留现场 */
                    File live = new File(getExternalFilesDir(null) != null
                            ? getExternalFilesDir(null) : getFilesDir(), "twinvm-live.log");
                    result = isRun ? Native.stage0(romPath(), live.getAbsolutePath()) : Native.probe();
                } catch (Throwable t) {
                    result = "异常: " + t;
                }
                final String r = result;
                /* 4.2：日志落盘——完整自检输出存文件（免截图/免 OCR 丢字）。
                 * 位置 /storage/emulated/0/Android/data/dev.twinbox.vm/files/（免权限，
                 * 文件管理器可见，长按可分享）。文件名 twinvm-时间戳.log */
                String saved = null;
                try {
                    File dir = getExternalFilesDir(null);
                    if (dir == null) dir = getFilesDir();
                    String stamp = new java.text.SimpleDateFormat(
                            "yyyyMMdd-HHmmss", java.util.Locale.US)
                            .format(new java.util.Date());
                    File logf = new File(dir, "twinvm-" + stamp + ".log");
                    FileOutputStream fo = new FileOutputStream(logf);
                    fo.write((r + "\n").getBytes("UTF-8"));
                    fo.close();
                    saved = logf.getAbsolutePath();
                } catch (Throwable ignore) { }
                final String savedPath = saved;
                mUi.post(new Runnable() {
                    @Override
                    public void run() {
                        mOut.setText(r);
                        if (savedPath != null)
                            mOut.append("\n\n[日志已保存] " + savedPath);
                        android.widget.Toast.makeText(MainActivity.this,
                                savedPath != null ? "日志已存: " + savedPath : "日志保存失败",
                                android.widget.Toast.LENGTH_LONG).show();
                    }
                });
            }
        }, "twinvm-selftest").start();
    }

    /** assets/demo.rom → filesDir（native 侧从文件 mmap 装载）。 */
    private String romPath() throws IOException {
        File f = new File(getFilesDir(), "demo.rom");
        InputStream in = getAssets().open("demo.rom");
        OutputStream o = new FileOutputStream(f);
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        o.close();
        in.close();
        return f.getAbsolutePath();
    }
}
