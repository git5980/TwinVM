#!/usr/bin/env python3
# 生成 TwinVM BPF 过滤器（安全原语放行清单 + 文件 I/O TRAP）
# 输出 core/src/bpf_gen.h（vm_backend_sigsys.c 直接 include）
import os

X86 = {
    'read': 0, 'write': 1, 'close': 3, 'fstat': 5, 'lseek': 8, 'mmap': 9,
    'mprotect': 10, 'munmap': 11, 'brk': 12, 'rt_sigaction': 13,
    'rt_sigprocmask': 14, 'ioctl': 16, 'pread64': 17, 'writev': 20,
    'mremap': 25, 'madvise': 28, 'exit': 60, 'wait4': 61, 'kill': 62,
    'uname': 63, 'fcntl': 72, 'getppid': 110, 'getcwd': 79, 'clone': 56, 'getpid': 39,
    'exit_group': 231, 'gettid': 186, 'futex': 202, 'set_tid_address': 218,
    'clock_gettime': 228, 'getrandom': 318, 'arch_prctl': 158,
    'sigaltstack': 131, 'tgkill': 234, 'sched_yield': 24, 'prctl': 157,
    'epoll_create1': 291, 'epoll_ctl': 233, 'epoll_wait': 232, 'epoll_pwait': 281, 'socket': 41,
    'connect': 42,
    'pipe2': 317, 'getcpu': 309, 'sched_setaffinity': 203, 'set_robust_list': 273, 'rseq': 334,
    'nanosleep': 35, 'clock_nanosleep': 230,
    'membarrier': 324, 'prlimit64': 302, 'gettimeofday': 96, 'userfaultfd': 323,
    'process_vm_readv': 310, 'process_vm_writev': 311,
    'sched_getaffinity': 203, 'rt_sigreturn': 15,
}
ARM = {
    'getcwd': 17, 'ioctl': 29, 'fcntl': 25, 'getdents64': 61, 'lseek': 62,
    'read': 63, 'write': 64, 'writev': 66, 'close': 57, 'pread64': 67, 'exit': 93,
    'exit_group': 94, 'set_tid_address': 96, 'futex': 98, 'kill': 129,
    'rt_sigaction': 134, 'rt_sigprocmask': 135, 'sigaltstack': 132,
    'tgkill': 131, 'clone': 220, 'sched_yield': 124, 'sched_getaffinity': 123,
    'uname': 160, 'getpid': 172, 'getppid': 173, 'gettid': 178, 'brk': 214, 'munmap': 215,
    'mremap': 216, 'mmap': 222, 'mprotect': 226, 'clock_gettime': 113,
    'getrandom': 278, 'prctl': 167, 'madvise': 233, 'rt_sigreturn': 139,
    'nanosleep': 101, 'clock_nanosleep': 115,
    'epoll_create1': 20, 'epoll_ctl': 21, 'epoll_pwait': 22, 'pread64': 67,
    'pipe2': 59, 'getcpu': 168, 'sched_setaffinity': 122, 'set_robust_list': 99, 'rseq': 293,
    'socket': 198, 'connect': 203,
    'membarrier': 283, 'prlimit64': 261, 'gettimeofday': 169, 'userfaultfd': 282,
    'process_vm_readv': 270, 'process_vm_writev': 271,
    'wait4': 260,
}

# 安全原语直达清单（guest 无需虚拟化的内核服务——半虚拟化分层）
#
# 铁律（v0.2.8 修复）：**判决表里任何"直发内核"(VM_PT*)的 syscall 都必须在这张放行清单里**。
# 原因：SIGSYS handler 里用裸 svc 直发同样会被本过滤器再判一次；若该 syscall 未被放行，
# 就会在 SIGSYS 被阻塞的状态下二次 TRAP —— 内核不执行该 syscall、信号挂起，等 guest 自己
# 恢复信号掩码后才"迟到"投递，此时 ucontext 已不是系统调用现场（寄存器是别处的垃圾），
# 用户态内核会拿垃圾参数执行一次完全无关的 syscall；更糟的是可能形成 handler 自递归。
# bionic 的 pthread_create 恰好在 clone 前后 sigprocmask(屏蔽全部信号)，
# 线程入口 __start_thread 的 gettid 与 __exit(线程退出 exit) 正好落在这个窗口里 ——
# 这就是 Stage 1 自检在 pthread 一步 "code=-31（SIGSYS）"、且控制台不再打 trap#N 的根因。
#   * exit      ：bionic __exit() 用它做线程退出；放行 = 该线程真的退出（而不是整个槽位）
#   * gettid    ：bionic __start_thread 第一件事；必须返回真实 tid，
#                 伪造 tid 会让 __pthread_internal_find()/pthread_kill 失去身份
#   * exit_group：guest 关机
ALWAYS = ['exit_group', 'rt_sigreturn', 'exit', 'gettid', 'getpid', 'getppid', 'brk', 'munmap',
          'mprotect', 'mremap', 'madvise', 'futex', 'set_tid_address', 'prctl',
          'rt_sigprocmask', 'sigaltstack', 'kill', 'tgkill',
          'wait4', 'clone', 'clock_gettime', 'getrandom', 'sched_yield',
          'sched_getaffinity', 'fcntl',
          'membarrier', 'prlimit64', 'gettimeofday', 'nanosleep', 'clock_nanosleep',
          'userfaultfd',   # v0.7.42：ART CC GC/FaultHandler 要它（真机日志：ENOSYS nr=282 → 之后静默卡死）
          'epoll_create1', 'epoll_ctl', 'epoll_wait', 'epoll_pwait',
          'pipe2', 'getcpu', 'sched_setaffinity',           # v0.7.49 铁律：**App 的 seccomp 策略 KILL 的 syscall 一律不得放行**！
          # 真机实测（v0.7.48 策略探针，fork 子进程逐个试调）——以下 11 条被
          # SECCOMP_RET_KILL_PROCESS 直接杀（绕过 handler 与屏蔽位，表现为
          # "无任何 TRAP 行 + code=-31"）：
          #   rseq(293) mbind(235) get_mempolicy(236) set_mempolicy(237)
          #   migrate_pages(238) move_pages(239) keyctl(250) add_key(248)
          #   request_key(249) openat2(437) faccessat2(439)
          # v0.7.52 补充（全量放行清单审计实测）：set_robust_list(99) 也在 KILL 名单里！
          #   bionic **每个线程**都会调它 → 曾导致 ART 在某次线程初始化后"无痕 code=-31"。
          # 其中 rseq 曾被本清单放行 —— ART/bionic 每个新线程都会调它，于是
          # 槽位必死。摘掉后它会 TRAP → 引擎回 -ENOSYS，bionic 按"内核不支持
          # rseq"正常退化。
          # v0.7.22：引擎自身在 handler 内用它们做安全访存（vm_mem_read/vm_mem_write），
          # guest 传野指针时只会 -EFAULT 而不是 handler 内 SIGSEGV 崩槽位。
          # Android app seccomp 策略允许（见 bionic SYSCALLS.TXT，不在 APP blocklist）。
          'process_vm_readv', 'process_vm_writev']
# 注意：mmap/pread64/rt_sigaction 不在此表——参数化（fd 路由/sig==31 保护）（见 emit）：fd 落虚拟区间才 TRAP，其余放行。
# 真文件 fd 误落区间时 handler 里 is_binder 复查兜底（宁可多 TRAP，不可漏截）。


def emit(nr_table, arch_const, has_arch_prctl):
    always = [n for n in ALWAYS if n in nr_table] + (['arch_prctl'] if has_arch_prctl else [])
    write_nr = nr_table['write']
    mmap_nr = nr_table['mmap']
    lines = []
    # 0: LD arch; 1: JEQ arch → +0 / →KILL（偏移最后 patch）
    lines.append('        BPF_STMT(BPF_LD | BPF_W | BPF_ABS, 4),')
    # 指令构建（占位跳转，稍后回填）
    prog = [('LD_ARCH', 4)]
    prog.append(('JEQ_ARCH', arch_const, None, 'KILL'))   # arch 检查：匹配→继续，不匹配→KILL
    for name in always:
        prog.append(('LD', 0, None, None))
        prog.append(('JEQ', nr_table[name], None, 'ALLOW'))
    # ── 4.0：fd 参数化四件套（真 fd 原生放行——handler 直发会二次 TRAP = v0.2.8 铁律违反，
    # 真机 v0.5.0 实锤：write(pipe_fd) TRAP→handler 直发→再 TRAP（SIGSYS 阻塞态）→code=-31 死）。
    # 语义：真内核 fd（pipe/epoll 等，3..9999）由 BPF 直接 ALLOW——guest 原生执行，不经 handler；
    #       console（write 直写；read/close/ioctl 保护性 TRAP）、stdio(0,1,2) 与虚拟区间(10000+) → TRAP。
    fd_blocks = []
    for sname, cons_tgt in [('write', 'ALLOW'), ('read', 'TRAP'), ('close', 'TRAP'), ('ioctl', 'TRAP')]:
        if sname not in nr_table:
            continue
        fd_blocks.append([
            ('LD', 0, None, None),
            ('JEQ', nr_table[sname], None, 'FD_BLK'),       # 命中→顺序查 fd；未命中→跳下一块
            ('LD', 16, None, None),                          # args[0] lo32 = fd
            ('JEQ', 'CONSOLE', None, cons_tgt),              # console 特判
            ('JGE', 10000, None, 'TRAP'),                    # fd≥10000（虚拟区间）→TRAP
            ('JGT', 2, None, 'ALLOW'),                       # 3..9999 真 fd→ALLOW 原生
            ('RET', 'SECCOMP_RET_TRAP', None, None),         # 0,1,2→TRAP（VM stdio 语义）
        ])
    # v0.7.16：socket 参数化——AF_UNIX(1) → ALLOW 原生直通（本地 IPC：stats/logd
    # 探测；connect 到不存在路径拿 ENOENT 无害）；其它族 → 顺序落 TRAP（handler 报
    # EACCES，VM 无真网络栈——Stage 5 halbox 桥再做）。
    # 铁律注意：socket 一律不在 handler 直发（v0.7.16 真机 -31 死实锤）。
    if 'socket' in nr_table:
        prog.append(('LD', 0, None, None))
        prog.append(('JEQ', nr_table['socket'], None, 'FD_BLK'))
        prog.append(('LD', 16, None, None))               # a0 = family
        prog.append(('JEQ', 1, None, 'ALLOW_LAST'))       # AF_UNIX → 尾部主 ALLOW
        prog.append(('RET', 'SECCOMP_RET_TRAP', None, None))  # 其它族 → 本块 TRAP（顺序落）
    # v0.7.24：connect 参数化——真 fd(3..9999) → ALLOW 原生（AF_UNIX：logd/statsd 必须能连上，
    # ART 的第一条日志就走这里）；虚拟 fd(≥10000)/stdio → TRAP 进 handler（只回错误，绝不直发）。
    # 铁律：handler 里**不许**用裸 svc 直发 connect（真机 2026-10-13 17:09 实锤：
    #   vm_core 里 VM_PT3(203) 直发 → 自家过滤器二次 TRAP → SIGSYS 挂起 → code=-31）。
    if 'connect' in nr_table:
        fd_blocks.append([
            ('LD', 0, None, None),
            ('JEQ', nr_table['connect'], None, 'FD_BLK'),
            ('LD', 16, None, None),
            ('JEQ', 'CONSOLE', None, 'TRAP'),
            ('JGE', 10000, None, 'TRAP'),
            ('JGT', 2, None, 'ALLOW'),
            ('RET', 'SECCOMP_RET_TRAP', None, None),
        ])
    # v0.7.6：rt_sigaction(sig==SIGSYS=31) → TRAP（保护处理器——厂商 linker 的
    # flowctrl 反调试会重置信号处置；伪造成功，VM handler 不动）
    if 'rt_sigaction' in nr_table:
        prog.append(('LD', 0, None, None))
        prog.append(('JEQ', nr_table['rt_sigaction'], None, 'FD_BLK'))
        prog.append(('LD', 16, None, None))               # a0 = sig
        # v0.7.53：sig==31 继续往下查 act；其它信号直接原生放行
        prog.append(('JEQ', 31, None, 'SIGSYS_CHK'))
        prog.append(('RET', 'SECCOMP_RET_ALLOW', None, None))  # 其它信号原生
        prog.append(('LD', 24, None, None))               # a1 = act（NULL=纯查询）
        prog.append(('JEQ', 0, None, 'ALLOW_LAST'))       # 纯查询 → 放行（引擎据此自查 handler）
        prog.append(('RET', 'SECCOMP_RET_TRAP', None, None))   # 安装企图 → 拦截（引擎伪造成功）
    # pread64：fd<10000（真 fd）→ ALLOW 原生；≥10000（虚拟）→ TRAP 进 handler（ROM 读）
    if 'pread64' in nr_table:
        prog.append(('LD', 0, None, None))
        prog.append(('JEQ', nr_table['pread64'], None, 'FD_BLK'))
        prog.append(('LD', 16, None, None))                # args[0]=fd（v0.7.5 修复：漏了这条）
        prog.append(('JGE', 10000, None, 'PREAD_TRAP'))   # 虚拟 fd → TRAP
        prog.append(('RET', 'SECCOMP_RET_ALLOW', None, None))  # 真 fd 原生
    for blk in fd_blocks:
        prog.extend(blk)
    # ── 3.1：mmap 参数化放行（真内核同款 fd 路由）──
    prog.append(('LD', 0, None, None))
    prog.append(('JEQ', mmap_nr, None, 'MMAP_CHK'))    # 命中 mmap→顺序查fd；未命中→默认 TRAP
    prog.append(('LD', 48, None, None))                 # args[4] lo32 = fd（LP64 LE）
    prog.append(('JGE', 10000, None, 'ALLOW'))          # fd < VM_FD_BASE(10000) → ALLOW
    prog.append(('JGT', 10000 + 64 - 1, None, 'ALLOW')) # fd > 10063 → ALLOW；区间内 → 顺序 RET TRAP
    prog.append(('RET', 'SECCOMP_RET_TRAP', None, None))
    prog.append(('RET', 'SECCOMP_RET_ALLOW', None, None))
    prog.append(('RET', 'SECCOMP_RET_KILL_PROCESS', None, None))

    # 回填跳转偏移
    # 找 RET 位置
    ret_idx = {}
    for i, ins in enumerate(prog):
        if ins[0] == 'RET':
            ret_idx[ins[1]] = i
    # 尾部主 RET（prog 末三连：TRAP/ALLOW/KILL）——跨块跳转的唯一合法目标。
    # 注意 ret_idx 被中间块覆盖，尾部真身 = 最后一次出现的位置：
    allow_last_idx = max(i for i, ins in enumerate(prog)
                         if ins[0] == 'RET' and ins[1] == 'SECCOMP_RET_ALLOW')
    trap_last_idx = max(i for i, ins in enumerate(prog)
                         if ins[0] == 'RET' and ins[1] == 'SECCOMP_RET_TRAP')
    kill_last_idx = max(i for i, ins in enumerate(prog)
                         if ins[0] == 'RET' and ins[1] == 'SECCOMP_RET_KILL_PROCESS')
    mmap_blk = None
    for i, ins in enumerate(prog):
        if ins[0] == 'LD' and ins[1] == 48:
            mmap_blk = i - 1   # JEQ mmap 那条
            break
    # fd 参数化块起点表（FD_BLK 的 jf 目标 = 下一块起点；末块跳 mmap 块）
    fd_starts = []
    for i, ins in enumerate(prog):
        if ins[0] == 'JEQ' and ins[3] == 'FD_BLK':
            fd_starts.append(i)   # 块内 JEQ 位置；块起点 = i-1（LD 0）
    out = []
    for i, ins in enumerate(prog):
        if ins[0] == 'LD_ARCH':
            out.append('BPF_STMT(BPF_LD | BPF_W | BPF_ABS, 4),')
        elif ins[0] == 'LD':
            out.append(f'BPF_STMT(BPF_LD | BPF_W | BPF_ABS, {ins[1]}),')
        elif ins[0] == 'JEQ_ARCH':
            dst = ret_idx['SECCOMP_RET_KILL_PROCESS']
            jt = dst - (i + 1)
            out.append(f'BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, {ins[1]}, 0, {jt}),')
        elif ins[0] == 'JEQ' and ins[3] == 'MMAP_CHK':
            # 命中 mmap → 顺序查 fd；未命中 → 默认 TRAP
            dst = ret_idx['SECCOMP_RET_TRAP']
            jf = dst - (i + 1)
            out.append(f'BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, {ins[1]}, 0, {jf}),')
        elif ins[0] == 'JEQ' and ins[3] == 'FD_BLK':
            # 命中→顺序查 fd（jt=0）；未命中→跳下一 fd 块起点（末块→mmap 块）
            bi = fd_starts.index(i)
            nxt = fd_starts[bi + 1] - 1 if bi + 1 < len(fd_starts) else mmap_blk
            jf = nxt - (i + 1)
            out.append(f'BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, {ins[1]}, 0, {jf}),')
        elif ins[0] == 'JEQ' and ins[3] == 'ALLOW_LAST':
            dst = allow_last_idx          # 尾部主 ALLOW（唯一真身，中间块内 ALLOW 不可跳）
            jt = dst - (i + 1)
            out.append(f'BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, {ins[1]}, {jt}, 0),')
        elif ins[0] == 'JEQ' and ins[3] == 'SIGSYS_CHK':
            # sig==31 → 落到下一条（继续查 act）；否则 → 本块末尾的 RET ALLOW
            skip_to = None
            for k in range(i + 1, len(prog)):
                if prog[k][0] == 'RET' and prog[k][1] == 'SECCOMP_RET_ALLOW':
                    skip_to = k
                    break
            # v0.7.54 修正：JEQ 后面紧跟的就是 RET ALLOW，所以
            #   sig==31 → 必须**跳过**那条 RET ALLOW（jt = skip_to+1-i-1）
            #   sig!=31 → 直接落下（jf=0）命中 RET ALLOW
            # 之前把 jf 当成"跳到 RET ALLOW"算成了 0，等于两条路都落进 ALLOW ——
            # 真机后果：链接器把自己的 SIGSYS handler 装上了，槽位第 14 个 syscall 就死。
            jt = (skip_to + 1) - (i + 1)
            out.append(f'BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, {ins[1]}, {jt}, 0),')
        elif ins[0] == 'JEQ' and ins[3] == 'SIGSYS_TRAP':
            dst = trap_last_idx           # 尾部主 TRAP（防中间块 RET 误跳）
            jt = dst - (i + 1)
            out.append(f'BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, {ins[1]}, {jt}, 0),')
        elif ins[0] == 'JEQ':
            val, target = ins[1], ins[3]
            dst = ret_idx['SECCOMP_RET_' + ('KILL_PROCESS' if target == 'KILL' else
                              'ALLOW' if target == 'ALLOW' else 'TRAP')]
            # JEQ val, jt(命中跳 dst), jf(落到 next=0)
            jt = dst - (i + 1)
            if isinstance(val, str):
                v = val  # arch 常量字符串
            else:
                v = str(val)
            if val == 'CONSOLE':
                v = '(uint32_t)console_fd'   # 4.0：console 值统一转运行时 fd（不限目标）
            elif target == 'KILL':
                v = 'AUDIT_ARCH_X86_64' if 'X86' in str(ins[1]) else 'AUDIT_ARCH_AARCH64'
                # arch 常量由 emit 参数给；这里退回用 arch_const
            out.append(f'BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, {v}, {jt}, 0),')
        elif ins[0] == 'JGE':
            if ins[3] == 'PREAD_TRAP':
                dst = ret_idx['SECCOMP_RET_TRAP']
                jt = dst - (i + 1)
                out.append(f'BPF_JUMP(BPF_JMP | BPF_JGE | BPF_K, {ins[1]}, {jt}, 0),')
            elif ins[3] == 'ALLOW':
                # mmap 语义：a<k（真 fd）→ ALLOW；a≥k → 顺序（下一检查）
                dst = ret_idx['SECCOMP_RET_ALLOW']
                jf = dst - (i + 1)
                out.append(f'BPF_JUMP(BPF_JMP | BPF_JGE | BPF_K, {ins[1]}, 0, {jf}),')
            else:
                # fd 块语义：a≥k（虚拟区间）→ TRAP；a<k → 顺序（JGT 检查）
                dst = ret_idx['SECCOMP_RET_TRAP']
                jt = dst - (i + 1)
                out.append(f'BPF_JUMP(BPF_JMP | BPF_JGE | BPF_K, {ins[1]}, {jt}, 0),')
        elif ins[0] == 'JGT':
            # JGT k：真（fd>k）→ 跳 ALLOW；假 → 顺序落（RET TRAP / 下一检查）
            dst = ret_idx['SECCOMP_RET_ALLOW']
            jt = dst - (i + 1)
            out.append(f'BPF_JUMP(BPF_JMP | BPF_JGT | BPF_K, {ins[1]}, {jt}, 0),')
        elif ins[0] == 'RET':
            out.append(f'BPF_STMT(BPF_RET | BPF_K, {ins[1]}),')
    return ' \\\n'.join(out), len(prog), always


def allow_table(nr_table, always):
    """放行清单（供运行时/离线一致性自检用）：{ 'name': nr, ... }"""
    return [(n, nr_table[n]) for n in always]


x86_code, x86_n, x86_always = emit(X86, 'AUDIT_ARCH_X86_64', True)
arm_code, arm_n, arm_always = emit(ARM, 'AUDIT_ARCH_AARCH64', False)


def emit_allow_macro(always, nr_table):
    pairs = ', '.join(f'{{"{n}", {nr_table[n]}}}' for n in always)
    return '{ ' + pairs + ' }'


x86_allow = emit_allow_macro(x86_always, X86)
arm_allow = emit_allow_macro(arm_always, ARM)

c = f'''/* BPF 过滤器（生成于 2026-10-12 Stage1，gen_bpf.py）——请勿手改
 * 分层：安全原语直达内核（半虚拟化——同 VMOS），文件 I/O TRAP 进用户态内核，
 * write(console) 直通避免 handler 递归。共 x86_64={x86_n} / arm64={arm_n} 条
 *
 * v0.2.8：exit（线程退出）/ gettid（线程入口）加入放行清单 —— 判决表里所有
 * VM_PT* 直发内核的 syscall 必须出现在 VM_BPF_ALLOW_NRS 里，否则 handler 内
 * 直发会二次 TRAP（内核不执行 + 信号挂起 + 迟到投递乱判决）。
 * v0.7.22：引擎自身在 handler 内调用的 syscall（process_vm_readv/writev）同样
 * 必须在放行清单里（vm_engine_syscall_nrs 自检）。 */
#if defined(__x86_64__)
#define VM_BPF_ALLOW_NRS_COUNT {len(x86_always)}
#define VM_BPF_INSTRUCTIONS {{ \\
{x86_code} \\
}}
/* 放行清单（名字, 号）——运行时一致性自检 + 离线回归测试使用 */
#define VM_BPF_ALLOW_NRS {x86_allow}
#else
#define VM_BPF_INSTRUCTIONS {{ \\
{arm_code} \\
}}
/* 放行清单（名字, 号）——运行时一致性自检 + 离线回归测试使用 */
#define VM_BPF_ALLOW_NRS_COUNT {len(arm_always)}
#define VM_BPF_ALLOW_NRS {arm_allow}
#endif
'''

out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'src', 'bpf_gen.h')
open(out_path, 'w').write(c)
print(f'x86_64: {x86_n} insns, arm64: {arm_n} insns -> {out_path}')
print(f'放行清单: x86_64 {len(x86_always)} 项 / arm64 {len(arm_always)} 项')
for n, nr in allow_table(ARM, arm_always):
    print(f'  arm64 放行 {n} = {nr}')
