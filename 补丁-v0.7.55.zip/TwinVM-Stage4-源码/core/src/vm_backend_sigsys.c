/* TwinVM 拦截后端：seccomp-BPF + SIGSYS（进程内内核）。
 *
 * VMOS 同型的免 root 虚拟化核心机制：
 *   1. guest 代码原生执行（同架构 → 零模拟损耗）
 *   2. BPF 过滤器把 guest 的系统调用全部转成 SIGSYS 信号
 *   3. SIGSYS 处理器在用户空间"执行"这次系统调用（VFS/ROM/控制台桥）
 *   4. 修改被中断上下文的返回值寄存器，跳过原指令继续
 *
 * 过滤器放行清单（其余全部 TRAP，见 gen_bpf.py / bpf_gen.h 的 VM_BPF_ALLOW_NRS）：
 *   exit_group / exit —— guest 关机 / 线程退出（bionic __exit）
 *   rt_sigreturn —— 信号框架完整性
 *   gettid 等"判决表直发"的安全原语（VM_PT*）—— 铁律：直发集合必须 ⊆ 放行清单，
 *      否则 handler 里裸 svc 会被本过滤器二次 TRAP（v0.2.8 修的 Stage 1 code=-31）
 *   write(fd==console) —— 控制台桥直通（处理器自身写管道不递归）
 */
#define _GNU_SOURCE
#include "vm_core.h"

#include <elf.h>

#include <errno.h>
#include <stdlib.h>
#include <linux/audit.h>
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/ucontext.h>
#if defined(__x86_64__)
#include <sys/reg.h>   /* REG_* 只有 x86_64 用得到（glibc-aarch64 没有这个头） */
#endif
/* glibc 的 REG_* 枚举不含 ORIG_RAX；gregs[15] 即 kernel user_regs_struct.orig_rax（REG_RIP=16 旁证） */
#define VM_REG_ORIG_RAX 15
#include <unistd.h>

#if defined(__x86_64__)
#define VM_ARCH_AUDIT AUDIT_ARCH_X86_64
#define VM_NR_write   1
#define VM_NR_rt_sigreturn 15
#define VM_NR_exit_group 231
#define VM_NR_arch_prctl 158
#elif defined(__aarch64__)
#define VM_ARCH_AUDIT AUDIT_ARCH_AARCH64
#define VM_NR_write   64
#define VM_NR_rt_sigreturn 139
#define VM_NR_exit_group 94
#else
#error "sigsys 后端仅支持 x86_64/aarch64"
#endif

/* BPF 程序（13 条，跳转偏移手工推导，改动需重算）：
 *   0 LD arch            1 JEQ ARCH,→2,→12(KILL)
 *   2 LD nr              3 JEQ exit_group →11(ALLOW)
 *   4 LD nr              5 JEQ rt_sigreturn →11(ALLOW)
 *   6 LD nr              7 JEQ write,→8,→10(TRAP)
 *   8 LD args[0]低32位   9 JEQ console_fd →11(ALLOW) else →10(TRAP)
 *  10 RET TRAP          11 RET ALLOW          12 RET KILL            */
static int vm_seccomp_install(int console_fd) {
    #include "bpf_gen.h"
    struct sock_filter prog[] = VM_BPF_INSTRUCTIONS;
    struct sock_fprog fprog = {
        .len = (unsigned short)(sizeof(prog) / sizeof(prog[0])),
        .filter = prog,
    };
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0) return -errno;
    if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &fprog, 0, 0) != 0) return -errno;
    return 0;
}

/* ── TLS 基址切换 ──
 * guest（bionic）会 arch_prctl/tpidr 设自己的 TLS；SIGSYS handler 是 glibc 宿主代码，
 * printf/锁全依赖宿主 TLS 基址——进入 handler 必须切回宿主，返回前恢复 guest。 */
static unsigned long g_libc_tls;

/* 后端自用的直发 syscall（vm_core 的 vm_syscall6 是 static） */
static long be_sys(long nr, long a, long b) {
#if defined(__x86_64__)
    long ret;
    __asm__ volatile("syscall" : "=a"(ret) : "a"(nr), "D"(a), "S"(b) : "rcx", "r11", "memory");
    return ret;
#else
    register long x8 __asm__("x8") = nr;
    register long x0 __asm__("x0") = a;
    register long x1 __asm__("x1") = b;
    __asm__ volatile("svc #0" : "+r"(x0) : "r"(x8), "r"(x1) : "memory", "cc");
    return x0;
#endif
}

/* 宿主（bionic）TLS 交换。v0.7.38：整块允许被预定义覆盖 ——
 * 白盒测试跑在 glibc 进程里，msr tpidr_el0 会把 libc 的 TLS 换掉直接崩。 */
#ifndef VM_TLS_GET
#if defined(__x86_64__)
#define VM_TLS_GET(p)  be_sys(158 /*arch_prctl*/, 0x1003 /*ARCH_GET_FS*/, (long)(p))
#define VM_TLS_SET(v)  be_sys(158, 0x1002 /*ARCH_SET_FS*/, (long)(v))
#else
static unsigned long rd_tpidr(void) { unsigned long v; __asm__ volatile("mrs %0, tpidr_el0" : "=r"(v)); return v; }
static void wr_tpidr(unsigned long v) { __asm__ volatile("msr tpidr_el0, %0" :: "r"(v)); }
#define VM_TLS_GET(p)  (*(unsigned long*)(p) = rd_tpidr(), 0)
#define VM_TLS_SET(v)  wr_tpidr((unsigned long)(v))
#endif
#endif /* VM_TLS_GET */

#ifndef SYS_SECCOMP
#define SYS_SECCOMP 1
#endif

/* ── 极简 seccomp-BPF 解释器（启动自检用）──
 * 只支持本生成器产出的指令形态：LD|W|ABS(0/4/16) / JEQ K / RET K。
 * 用途：在真正 prctl(PR_SET_SECCOMP) 之前，把"判决表直发集合"逐个喂进过滤器，
 * 确认它们都被判成 ALLOW —— 这是 v0.2.8 修的 bug 的运行时护栏。 */
static long vm_bpf_eval(const struct sock_filter* prog, size_t n, uint32_t nr,
                        uint32_t arch, uint64_t arg0, uint32_t console_fd, uint64_t arg4) {
    uint32_t a = 0;
    size_t pc = 0;
    for (int guard = 0; guard < 4096 && pc < n; guard++) {
        uint16_t code = prog[pc].code;
        uint8_t cls = (uint8_t)(code & 0x07);
        if (cls == 0x00 && (code & 0x18) == 0x00) {          /* BPF_LD|BPF_W|BPF_ABS */
            switch (prog[pc].k) {
                case 0:  a = nr;             break;
                case 4:  a = arch;           break;
                case 16: a = (uint32_t)arg0; break;
                case 48: a = (uint32_t)arg4; break;   /* 3.1：mmap args[4]=fd */
                default: return -1;
            }
            pc++;
        } else if (cls == 0x05 && (code & 0xf0) == 0x10) {   /* BPF_JMP|BPF_JEQ|BPF_K */
            uint32_t k = prog[pc].k;
            pc += 1 + (size_t)((a == k) ? prog[pc].jt : prog[pc].jf);
        } else if (cls == 0x05 && (code & 0xf0) == 0x30) {   /* BPF_JMP|BPF_JGE|BPF_K */
            uint32_t k = prog[pc].k;
            pc += 1 + (size_t)((a >= k) ? prog[pc].jt : prog[pc].jf);
        } else if (cls == 0x05 && (code & 0xf0) == 0x20) {   /* BPF_JMP|BPF_JGT|BPF_K */
            uint32_t k = prog[pc].k;
            pc += 1 + (size_t)((a > k) ? prog[pc].jt : prog[pc].jf);
        } else if (cls == 0x06) {                            /* BPF_RET|BPF_K */
            return (long)prog[pc].k;
        } else {
            return -1;
        }
    }
    return -1;
}

#define VM_SECCOMP_RET_ALLOW 0x7fff0000L

/* v0.7.24：给 vm_core 的"直发内核"(VM_PT*)通道做运行时护栏用。
 * 返回过滤器对这次调用的判决（VM_SECCOMP_RET_ALLOW / TRAP / KILL_PROCESS），-1=不认识。
 * 为什么要它：只靠"直发清单表 + 启动自检"是**手维护**的——2026-10-13 17:09 真机实锤：
 * 有人在判决表里加了 connect(203) 的 VM_PT3 直发，但没登记进表，自检静默通过，
 * 结果 handler 内裸 svc 被自家过滤器二次 TRAP（SIGSYS 阻塞态）→ 挂起 → code=-31。
 * 现在每次直发前都问一遍过滤器：不放行就拒绝直发、返回 -ENOSYS，这类事故不可能再发生。 */
long vm_filter_action(long nr, long a0, long a1, long a2, long a3, long a4, long a5) {
    (void)a1; (void)a2; (void)a3; (void)a5;
    int console_fd = vm_console_fd;
    struct sock_filter prog[] = VM_BPF_INSTRUCTIONS;
    size_t n = sizeof(prog) / sizeof(prog[0]);
    return vm_bpf_eval(prog, n, (uint32_t)nr, VM_ARCH_AUDIT,
                       (uint64_t)a0, (uint32_t)console_fd, (uint64_t)a4);
}
#if defined(__x86_64__)
#define VM_NR_mmap_selftest 9
#else
#define VM_NR_mmap_selftest 222
#endif

int vm_filter_check_passthrough(void) {
    int console_fd = vm_console_fd;          /* VM_BPF_INSTRUCTIONS 里引用这个名字 */
    struct sock_filter prog[] = VM_BPF_INSTRUCTIONS;
    size_t n = sizeof(prog) / sizeof(prog[0]);
    int bad = 0;
    for (int i = 0; i < vm_passthrough_nr_count; i++) {
        long nr = vm_passthrough_nrs[i];
        /* 3.1：mmap 参数化——直发自检用普通 fd（非虚拟区间）评估 */
        long act = vm_bpf_eval(prog, n, (uint32_t)nr, VM_ARCH_AUDIT, 0, (uint32_t)console_fd, 0);
        if (act != VM_SECCOMP_RET_ALLOW) {
            bad++;
            vm_log("!! 直发清单自检失败: nr=%ld 在 BPF 里被判为 0x%lx（应为 ALLOW）"
                   "—— handler 内直发会二次 TRAP（Stage 1 code=-31 同型故障）", nr, act);
        }
    }
    /* 3.1 正向护栏：mmap+虚拟 binder fd 必须被判 TRAP（零拷贝段截获入口）。
     * 反向（普通 fd → ALLOW）已由上面直发清单的 mmap+arg4=0 项覆盖。 */
    {
        struct sock_filter prog2[] = VM_BPF_INSTRUCTIONS;
        size_t n2 = sizeof(prog2) / sizeof(prog2[0]);
        uint32_t mm = (uint32_t)VM_NR_mmap_selftest;
        long act = vm_bpf_eval(prog2, n2, mm, VM_ARCH_AUDIT, 0, (uint32_t)console_fd, VM_FD_BASE);
        if (act == VM_SECCOMP_RET_ALLOW) {
            bad++;
            vm_log("!! mmap 参数化护栏失败: 虚拟 fd=%d 应判 TRAP 却 ALLOW——零拷贝段截获将失效", VM_FD_BASE);
        }
    }
    /* v0.7.22：引擎自身在 handler 内调用的 syscall（process_vm_readv/writev）也必须放行。
     * 一旦漏了，vm_mem_read/write 在 handler 里就会二次 TRAP —— 野指针防护反而变成死机源。 */
    for (int i = 0; i < vm_engine_syscall_nr_count; i++) {
        long nr = vm_engine_syscall_nrs[i];
        long act = vm_bpf_eval(prog, n, (uint32_t)nr, VM_ARCH_AUDIT, 0, (uint32_t)console_fd, 0);
        if (act != VM_SECCOMP_RET_ALLOW) {
            bad++;
            vm_log("!! 引擎自用 syscall 未放行: nr=%ld 判为 0x%lx（应为 ALLOW）"
                   "—— handler 内安全访存会二次 TRAP（会崩槽位）", nr, act);
        }
    }
    return bad;
}

/* ── 迟到/串味投递防护（v0.2.8）──
 * 若 guest 在自己把 SIGSYS 屏蔽了的窗口里触发 TRAP（bionic pthread_create 在
 * clone 前后就是这么干的），内核不会立刻投递：syscall 被丢弃、SIGSYS 挂起，直到
 * guest 自己 rt_sigprocmask 恢复掩码才投递。此刻 ucontext 里的寄存器早已不是系统
 * 调用现场，拿 r[8] 当 nr、拿 r[0..5] 当参数就会执行一次完全无关的 syscall
 * （甚至 handler 自递归）。判据：seccomp 生成信号时内核记下 si_call_addr
 * （= 出事当时的 PC）；若它与信号真正投递时的 ucontext PC 不一致，即为迟到投递 ——
 * 只告警、不判决。 */
static uintptr_t vm_ucontext_pc(ucontext_t* uc) {
#if defined(__x86_64__)
    return (uintptr_t)uc->uc_mcontext.gregs[REG_RIP];
#else
    return (uintptr_t)uc->uc_mcontext.pc;
#endif
}

static void vm_warn_stale(long nr, uintptr_t trap_pc, uintptr_t now_pc) {
    static long stale_count;      /* 限频：前 8 条 + 每 64 条一条 */
    if (stale_count < 8 || (stale_count & 0x3F) == 0) {
        char b[192];
        int k = snprintf(b, sizeof(b),
                         "[TwinVM] 迟到 TRAP nr=%ld（生成于 0x%lx，投递于 0x%lx）："
                         "该 syscall 在 SIGSYS 被屏蔽的窗口里已被内核丢弃，本次不判决\n",
                         nr, (unsigned long)trap_pc, (unsigned long)now_pc);
        vm_console_write(b, (size_t)k);
    }
    stale_count++;
}

/* SIGSYS：guest 的系统调用落点 —— 用户态内核入口 */
static void vm_sigsys_handler(int sig, siginfo_t* si, void* vuc) {
    (void)sig;
    ucontext_t* uc = (ucontext_t*)vuc;
    VmCpu* c = vm_cpu_current();
    if (!c) _exit(91);
    /* v0.7.53 的 in-handler sigaction() 自查已移除（v0.7.54）：
     * 信号处理器里调用 sigaction 不是异步信号安全的，而且它只能证明"现在"，
     * 证明不了"死的那一刻"。改用父进程读 /proc/<pid>/status 的 SigCgt
     * （blackbox 已经在打）——僵尸进程的该字段仍然保留，能直接看出
     * SIGSYS 是否还在"被捕获"位里。 */

#if defined(__x86_64__)
    c->guest_sp = (uintptr_t)uc->uc_mcontext.gregs[REG_RSP];
#else
    c->guest_sp = (uintptr_t)uc->uc_mcontext.sp;
#endif

    long nr = (long)si->si_syscall;                 /* 内核给的号 = 唯一可信来源 */
    vm_bb_pc((unsigned long)vm_ucontext_pc(uc));    /* v0.7.50: 共享黑匣子补 PC */
    uintptr_t now_pc = vm_ucontext_pc(uc);
#ifdef si_call_addr
    uintptr_t trap_pc = (uintptr_t)si->si_call_addr;   /* 内核生成信号瞬间的 PC */
#else
    uintptr_t trap_pc = 0;                             /* 头文件没暴露该字段：不做迟到检测 */
#endif
    int stale = (si->si_code == SYS_SECCOMP && trap_pc != 0 && trap_pc != now_pc);

    if (stale) {                                    /* 迟到投递：绝不按系统调用判决 */
        vm_warn_stale(nr, trap_pc, now_pc);
        return;
    }

    /* TLS 保全：guest 与 libc 宿主的 TLS 基址切换（bionic 抢占 FS/tpidr 后
     * 宿主 glibc 的 printf/锁会读错地址——第一次能打日志第二次必炸的根因） */
    unsigned long saved_tls = 0;   /* 局部保存=线程安全（bionic 子线程 TRAP 时不踩主线程槽） */
    int tls_swapped = 0;
    VM_TLS_GET(&saved_tls);
    if (saved_tls != g_libc_tls) { VM_TLS_SET(g_libc_tls); tls_swapped = 1; }

    {   /* 4.2 排障：前 512 条 TRAP 打 nr+pc+参数。必须在 TLS 交换后（vm_log=glibc：
         * bionic FS 下 snprintf 读 TLS 内部直接 SIGSEGV——x86 本地静态死之谜的真相）
         * v0.7.18：64→512（.so 装载阶段就吃满 64，ART init 全程盲区） */
        static long n4;
        if (n4 < 4096 && nr != 227) {   /* 227=msync：ART 会逐页 flush，噪声太大 */   /* v0.7.46: 512 太小 —— 死亡现场恰好总在 512 之后 */
            n4++;
#if defined(__x86_64__)
            greg_t* gx0 = uc->uc_mcontext.gregs;
            vm_log("[4.2dbg] TRAP#%ld nr=%ld pc=0x%llx a0=0x%llx a1=0x%llx a2=0x%llx stale=%d", n4, nr,
                   (unsigned long long)now_pc,
                   (unsigned long long)(uintptr_t)gx0[REG_RDI],
                   (unsigned long long)(uintptr_t)gx0[REG_RSI],
                   (unsigned long long)(uintptr_t)gx0[REG_RDX], stale);
#else
            uint64_t* rx0 = uc->uc_mcontext.regs;
            vm_log("[4.2dbg] TRAP#%ld nr=%ld pc=0x%llx a0=0x%llx a1=0x%llx a2=0x%llx stale=%d", n4, nr,
                   (unsigned long long)now_pc,
                   (unsigned long long)rx0[0],
                   (unsigned long long)rx0[1],
                   (unsigned long long)rx0[2], stale);
#endif
        }
    }
#if defined(__x86_64__)
#define VM_NR_execve 59
#else
#define VM_NR_execve 221
#endif

    /* Stage 2.1：虚拟 execve —— guest 的进程创建走用户态内核装载（VMOS libkrnloader 语义）。
     * 从 ROM 装载新映像 + 构造真 argv/envp 新栈，改写被中断上下文 PC/SP 直接跳进
     * 新程序 = execve 成功语义（永不返回）。ROM 未命中 → -ENOENT。
     * 注意：必须在 TLS 交换之后执行（loader 用宿主 libc）；static 字符串缓冲避免
     * 大数组在信号栈上的溢出风险。 */
    if (nr == VM_NR_execve) {
        char path[VM_MAX_PATH + 1];
        long e0 = -2 /* ENOENT */;
#if defined(__x86_64__)
        greg_t* gx = uc->uc_mcontext.gregs;
        uintptr_t p0 = (uintptr_t)gx[REG_RDI];
        uintptr_t p1 = (uintptr_t)gx[REG_RSI];
        uintptr_t p2 = (uintptr_t)gx[REG_RDX];
#else
        uint64_t* rx = uc->uc_mcontext.regs;
        uintptr_t p0 = (uintptr_t)rx[0];
        uintptr_t p1 = (uintptr_t)rx[1];
        uintptr_t p2 = (uintptr_t)rx[2];
#endif
        do {
            if (vm_mem_read(&c->mem, path, p0, VM_MAX_PATH) != 0) { e0 = -14; break; }
            path[VM_MAX_PATH] = 0;
            const VmRomInode* ino = vm_rom_find(c->vfs->rom, path);
            if (!ino) break;
            static char strs[16384];
            size_t so = 0;
            char* gav[64]; char* gev[64];
            int na = 0, ne = 0, ok = 1;
            for (int side = 0; side < 2 && ok; side++) {
                uintptr_t vec = side ? p2 : p1;
                if (!vec) break;
                char** dst = side ? gev : gav;
                int* cnt = side ? &ne : &na;
                for (int i = 0; i < 63 && ok; i++) {
                    uintptr_t sp = 0;
                    if (vm_mem_read(&c->mem, &sp, vec + (size_t)i * 8, 8) != 0) { ok = 0; break; }
                    if (sp == 0) break;
                    size_t l = 0;
                    while (l < 1024) {
                        if (vm_mem_read(&c->mem, strs + so + l, sp + l, 1) != 0) { ok = 0; break; }
                        if (strs[so + l] == 0) break;
                        l++;
                    }
                    if (!ok || so + l + 1 > sizeof(strs)) { ok = 0; break; }
                    dst[i] = strs + so;
                    so += l + 1;
                    (*cnt)++;
                }
            }
            if (!ok) { e0 = -14; break; }
            gav[na] = NULL; gev[ne] = NULL;
            VmLaunch L;
            const Elf64_Ehdr* teh = (const Elf64_Ehdr*)ino->map;
            vm_log("[4.2dbg] execve: ET_DYN=%u interp=%s", teh->e_type, "…");
            if (teh->e_type == ET_DYN) {
                /* 4.2：动态 PIE——找 PT_INTERP，ROM 里取真 linker，内核角色全演 */
                const Elf64_Phdr* tph = (const Elf64_Phdr*)(ino->map + teh->e_phoff);
                const char* ipath = NULL;
                for (int i = 0; i < teh->e_phnum && !ipath; i++)
                    if (tph[i].p_type == PT_INTERP)
                        ipath = (const char*)(ino->map + tph[i].p_offset);
                const VmRomInode* ld = NULL;
                if (ipath && ipath + strlen(ipath) < (const char*)ino->map + ino->size
                    && (ld = vm_rom_find(c->vfs->rom, ipath)) != NULL) {
                    vm_set_exec_path(path);
                    vm_set_exec_cmdline(gav);   /* /proc/self/cmdline */   /* /proc/self/exe 数据源 */
                    int rr = vm_loader_exec_dyn(ino->map, ino->size, ld->map, ld->size,
                                                 path, gav, gev, &L);
                    vm_log("[4.2dbg] exec_dyn ret=%d", rr);
                    if (rr == 0) {
                        e0 = 0;
                    } else { e0 = -8; break; }
                } else { vm_log("[4.2dbg] exec_dyn 未执行：interp=%s ld=%s", ipath ? ipath : "(null)", ld ? "ok" : "ROM缺"); e0 = -2; break; }
            } else {
                vm_set_exec_path(path);
                if (vm_loader_exec(ino->map, ino->size, gav, gev, &L) != 0) { e0 = -8; break; }
            }
#if defined(__x86_64__)
            gx[REG_RIP] = (greg_t)L.entry;
            gx[REG_RSP] = (greg_t)L.sp;
            gx[REG_RAX] = 0;
#else
            uc->uc_mcontext.pc = (unsigned long)L.entry;
            uc->uc_mcontext.sp = (unsigned long)L.sp;
            rx[0] = 0;
#endif
            if (tls_swapped) VM_TLS_SET(saved_tls);
            return;
        } while (0);
        /* execve 失败：写 -errno 正常返回（execve 失败会返回） */
#if defined(__x86_64__)
        gx[REG_RAX] = (greg_t)e0;
#else
        rx[0] = (unsigned long)e0;
#endif
        if (tls_swapped) VM_TLS_SET(saved_tls);
        return;
    }


#if defined(__x86_64__)
    greg_t* g = uc->uc_mcontext.gregs;
    long a0 = g[REG_RDI], a1 = g[REG_RSI], a2 = g[REG_RDX], a3 = g[REG_R10];
    long a4 = g[REG_R8],  a5 = g[REG_R9];
    long ret = vm_handle_syscall(c, nr, a0, a1, a2, a3, a4, a5);
    g[REG_RAX] = (greg_t)ret;
#else
    uint64_t* r = uc->uc_mcontext.regs;
    /* 同步投递时 r[8] 与 si_syscall 一致；不一致说明现场已串味，一律以内核号为准 */
    long ret = vm_handle_syscall(c, nr, (long)r[0], (long)r[1], (long)r[2],
                                 (long)r[3], (long)r[4], (long)r[5]);
    r[0] = (unsigned long)ret;
#endif
    if (tls_swapped) VM_TLS_SET(saved_tls);   /* 恢复本线程进入时的 TLS 基址 */
}

int vm_sigsys_install(int console_fd) {
    VM_TLS_GET(&g_libc_tls);   /* 宿主 TLS 基址必须在 guest 抢占前捕获 */
    if (vm_filter_check_passthrough() != 0)     /* 直发清单 ⊆ BPF 放行清单（v0.2.8 铁律） */
        vm_log("警告：过滤器与判决表不一致，guest 线程/直发路径可能二次 TRAP");
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = vm_sigsys_handler;
    sa.sa_flags = SA_SIGINFO;              /* 不设 NODEFER：处理器内自动屏蔽同信号 */
    if (sigaction(SIGSYS, &sa, NULL) != 0) return -errno;
    return vm_seccomp_install(console_fd);
}
