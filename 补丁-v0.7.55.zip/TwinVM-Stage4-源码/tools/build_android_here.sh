#!/bin/bash
# 在「aarch64 容器 + 无 x86_64 NDK 工具」的环境里交叉编译 Android arm64 产物。
# 原理：Ubuntu clang 18 负责前端/驱动，NDK r26d 的 sysroot（bionic 头/库，架构相关但与宿主无关）
#       提供 Android API-24 的头与库，lld 负责链接。等价于 build.sh 里 clang --target=aarch64-linux-android24。
set -e
NDK=${NDK:-/root/android-ndk-r26d/toolchains/llvm/prebuilt/linux-x86_64}
S=$NDK/sysroot; RD=$NDK/lib/clang/17
CC="clang --target=aarch64-linux-android24 --sysroot=$S -resource-dir=$RD --rtlib=compiler-rt -O2 -Wall -Wshadow -fno-stack-protector"
cd "$(dirname "$0")/.."

echo "== libtwinvm.so =="
$CC -Icore/src -shared -fPIC -Icore/include -o android/libtwinvm.so \
    core/src/vm_core.c core/src/vm_binder.c core/src/vm_rom.c core/src/vm_loader.c \
    core/src/vm_backend_sigsys.c android/jni/twinvm_jni.c -llog

echo "== /bin/guest（静态 EXEC） =="
$CC -static -fno-pic -no-pie -o build_guest64 core/guest/guest_stage42.c

echo "== /bin/probe（动态 PIE，诊断用） =="
$CC -pie -fPIE -o build_probe core/guest/guest_probe.c

echo "== ROM（fixture 所有顶层目录 + guest/probe + 启动镜像） =="
OUT=build_romroot; rm -rf $OUT; mkdir -p $OUT/bin $OUT/rom
cp build_guest64 $OUT/bin/guest; cp build_probe $OUT/bin/probe
cp rom/fixture/rom/hello.txt rom/fixture/dex/hello.dex $OUT/rom/
for d in rom/fixture/android_root/*; do b=$(basename "$d"); [ "$b" = bin ] && continue; [ "$b" = rom ] && continue; cp -r "$d" "$OUT/$b"; done
python3 rom/rompack.py pack $OUT android/assets/demo.rom
python3 rom/checkrom.py android/assets/demo.rom --strict
